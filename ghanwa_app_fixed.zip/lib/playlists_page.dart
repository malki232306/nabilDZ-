import 'package:flutter/material.dart';
import 'models.dart';
import 'edit_playlist_page.dart';
import 'playlist_audio_player.dart';

class PlaylistsPage extends StatefulWidget {
  @override
  State<PlaylistsPage> createState() => _PlaylistsPageState();
}

class _PlaylistsPageState extends State<PlaylistsPage> {
  List<OfflinePlaylist> playlists = [
    OfflinePlaylist(name: 'مفضلتي', songs: [
      Song(title: 'أغنية 1', artist: 'فنان 1'),
      Song(title: 'أغنية 2', artist: 'فنان 2'),
    ]),
  ];

  void _addPlaylist() async {
    final newPlaylist = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditPlaylistPage()),
    );
    if (newPlaylist != null && newPlaylist is OfflinePlaylist) {
      setState(() {
        playlists.add(newPlaylist);
      });
    }
  }

  void _openPlaylist(OfflinePlaylist playlist) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PlaylistAudioPlayer(playlist: playlist)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('قوائم التشغيل')),
      body: ListView.builder(
        itemCount: playlists.length,
        itemBuilder: (_, index) {
          final playlist = playlists[index];
          return ListTile(
            title: Text(playlist.name),
            subtitle: Text('${playlist.songs.length} أغنية'),
            onTap: () => _openPlaylist(playlist),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addPlaylist,
        child: Icon(Icons.add),
      ),
    );
  }
}