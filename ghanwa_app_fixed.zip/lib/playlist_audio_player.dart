import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'models.dart';

class PlaylistAudioPlayer extends StatefulWidget {
  final OfflinePlaylist playlist;

  PlaylistAudioPlayer({required this.playlist});

  @override
  _PlaylistAudioPlayerState createState() => _PlaylistAudioPlayerState();
}

class _PlaylistAudioPlayerState extends State<PlaylistAudioPlayer> {
  late AudioPlayer _player;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    if (widget.playlist.songs.isNotEmpty) {
      _playSongAtIndex(_currentIndex);
    }

    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _nextSong();
      }
    });
  }

  void _playSongAtIndex(int index) async {
    final song = widget.playlist.songs[index];
    final path = '/storage/emulated/0/Download/\${song.title}.mp3';

    try {
      await _player.setFilePath(path);
      _player.play();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في تشغيل الأغنية: \${song.title}')),
      );
    }
  }

  void _nextSong() {
    if (_currentIndex < widget.playlist.songs.length - 1) {
      _currentIndex++;
      _playSongAtIndex(_currentIndex);
      setState(() {});
    } else {
      _player.stop();
    }
  }

  void _previousSong() {
    if (_currentIndex > 0) {
      _currentIndex--;
      _playSongAtIndex(_currentIndex);
      setState(() {});
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.playlist.songs.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.playlist.name)),
        body: Center(child: Text('لا توجد أغاني في هذه القائمة')),
      );
    }

    final currentSong = widget.playlist.songs[_currentIndex];

    return Scaffold(
      appBar: AppBar(title: Text(widget.playlist.name)),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (currentSong.coverUrl != null)
            Image.network(currentSong.coverUrl!)
          else
            Icon(Icons.music_note, size: 150, color: Colors.deepPurple),
          SizedBox(height: 20),
          Text(currentSong.title, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Text(currentSong.artist, style: TextStyle(fontSize: 18)),
          SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(icon: Icon(Icons.skip_previous), onPressed: _previousSong),
              StreamBuilder<PlayerState>(
                stream: _player.playerStateStream,
                builder: (context, snapshot) {
                  final playerState = snapshot.data;
                  final playing = playerState?.playing ?? false;
                  return IconButton(
                    icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                    iconSize: 48,
                    onPressed: () {
                      if (playing) {
                        _player.pause();
                      } else {
                        _player.play();
                      }
                    },
                  );
                },
              ),
              IconButton(icon: Icon(Icons.skip_next), onPressed: _nextSong),
            ],
          ),
        ],
      ),
    );
  }
}