import 'package:flutter/material.dart';
import 'models.dart';

class EditPlaylistPage extends StatefulWidget {
  @override
  State<EditPlaylistPage> createState() => _EditPlaylistPageState();
}

class _EditPlaylistPageState extends State<EditPlaylistPage> {
  final TextEditingController _nameController = TextEditingController();
  final List<Song> _songs = [];

  final TextEditingController _songTitleController = TextEditingController();
  final TextEditingController _songArtistController = TextEditingController();

  void _addSong() {
    final title = _songTitleController.text.trim();
    final artist = _songArtistController.text.trim();
    if (title.isNotEmpty && artist.isNotEmpty) {
      setState(() {
        _songs.add(Song(title: title, artist: artist));
        _songTitleController.clear();
        _songArtistController.clear();
      });
    }
  }

  void _savePlaylist() {
    final name = _nameController.text.trim();
    if (name.isNotEmpty && _songs.isNotEmpty) {
      final playlist = OfflinePlaylist(name: name, songs: List.from(_songs));
      Navigator.pop(context, playlist);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('يرجى إدخال اسم القائمة وإضافة أغنية واحدة على الأقل')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إنشاء / تعديل قائمة تشغيل')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'اسم قائمة التشغيل'),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _songTitleController,
              decoration: InputDecoration(labelText: 'عنوان الأغنية'),
            ),
            TextField(
              controller: _songArtistController,
              decoration: InputDecoration(labelText: 'اسم الفنان'),
            ),
            ElevatedButton(onPressed: _addSong, child: Text('إضافة أغنية')),
            SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: _songs.length,
                itemBuilder: (_, index) {
                  final song = _songs[index];
                  return ListTile(
                    title: Text(song.title),
                    subtitle: Text(song.artist),
                  );
                },
              ),
            ),
            ElevatedButton(onPressed: _savePlaylist, child: Text('حفظ قائمة التشغيل')),
          ],
        ),
      ),
    );
  }
}