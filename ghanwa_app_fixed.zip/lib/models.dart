class Song {
  final String title;
  final String artist;
  final String? coverUrl;

  Song({required this.title, required this.artist, this.coverUrl});
}

class OfflinePlaylist {
  final String name;
  final List<Song> songs;

  OfflinePlaylist({required this.name, required this.songs});
}