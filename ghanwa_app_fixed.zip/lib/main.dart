import 'package:flutter/material.dart';
import 'playlists_page.dart';

void main() {
  runApp(const GhanwaApp());
}

class GhanwaApp extends StatelessWidget {
  const GhanwaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'غنوة - Ghanwa',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: PlaylistsPage(),
    );
  }
}